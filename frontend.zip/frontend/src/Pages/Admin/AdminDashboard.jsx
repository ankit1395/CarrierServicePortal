import React from "react";

export default function AdminDashboard() {
  return (
    <>
      <h1>Welcome to the  Admin Dashboard</h1>
    </>
  );
}
